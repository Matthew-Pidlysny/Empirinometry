#!/usr/bin/env python3
"""
Test Tools for Minimum Field Theory Analysis
Includes computational verification and mathematical validation utilities
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import minimize
import json
from datetime import datetime

class MFTAnalyzer:
    """Comprehensive analyzer for Minimum Field Theory properties"""
    
    def __init__(self):
        self.results = {}
        self.timestamp = datetime.now().isoformat()
        
    def analyze_10_4321_properties(self):
        """Analyze hypothetical connections between 10^4321 and MFT"""
        print("=== Analyzing 10^4321 for MFT Relevance ===")
        
        # Mathematical properties
        exponent = 4321
        digit_sum = sum(int(d) for d in str(exponent))
        
        properties = {
            'exponent': exponent,
            'digit_sum': digit_sum,
            'is_prime': self._is_prime(exponent),
            'mod_patterns': self._compute_mod_patterns(exponent),
            'mft_relevance': self._assess_mft_relevance(exponent, digit_sum)
        }
        
        self.results['10_4321_analysis'] = properties
        return properties
    
    def _is_prime(self, n):
        """Check if number is prime"""
        if n < 2:
            return False
        for i in range(2, int(np.sqrt(n)) + 1):
            if n % i == 0:
                return False
        return True
    
    def _compute_mod_patterns(self, exponent, mods=[2,3,5,7,11,13,17]):
        """Compute modular patterns for field analysis"""
        patterns = {}
        for mod in mods:
            # Using modular exponentiation
            result = pow(10, exponent, mod)
            patterns[f'mod_{mod}'] = result
        return patterns
    
    def _assess_mft_relevance(self, exponent, digit_sum):
        """Assess potential relevance to MFT"""
        relevance_score = 0
        insights = []
        
        # Check digit sum pattern
        if digit_sum == 10:
            relevance_score += 0.3
            insights.append("Digit sum equals base (10) - potential field alignment")
        
        # Check prime-like properties
        if self._is_prime(exponent):
            relevance_score += 0.2
            insights.append("Exponent is prime - suggests fundamental structure")
        
        # Check modulo patterns for field symmetry
        mods = [3, 7, 11, 13]
        symmetric_count = 0
        for mod in mods:
            if pow(10, exponent, mod) in [1, mod-1]:
                symmetric_count += 1
        
        if symmetric_count >= 2:
            relevance_score += 0.2
            insights.append("Symmetric modulo patterns - field relevance")
        
        # Magnitude consideration
        if exponent > 1000:
            relevance_score += 0.1
            insights.append("Large magnitude - field expansion modeling potential")
        
        # Binary representation patterns
        binary = bin(exponent)[2:]
        if binary.count('1') / len(binary) > 0.4:
            relevance_score += 0.1
            insights.append("Balanced binary representation - computational efficiency")
        
        return {
            'score': min(relevance_score, 1.0),
            'insights': insights
        }
    
    def field_minimization_test(self, field_type='scalar', dimension=2):
        """Test field minimization principles"""
        print(f"=== Testing {field_type} Field Minimization ===")
        
        # Create test field
        if field_type == 'scalar':
            field = self._create_scalar_field(dimension)
        elif field_type == 'vector':
            field = self._create_vector_field(dimension)
        else:
            field = self._create_tensor_field(dimension)
        
        # Minimize energy functional
        result = minimize(self._energy_functional, field.flatten(), 
                         args=(field_type, dimension),
                         method='L-BFGS-B')
        
        minimized_field = result.x.reshape(field.shape)
        final_energy = result.fun
        
        test_results = {
            'field_type': field_type,
            'dimension': dimension,
            'initial_energy': self._energy_functional(field.flatten(), field_type, dimension),
            'final_energy': final_energy,
            'convergence': result.success,
            'iterations': result.nit
        }
        
        self.results[f'minimization_{field_type}'] = test_results
        return test_results
    
    def _create_scalar_field(self, dimension, size=20):
        """Create test scalar field"""
        x = np.linspace(-1, 1, size)
        if dimension == 1:
            return np.random.randn(size) * 0.1
        elif dimension == 2:
            X, Y = np.meshgrid(x, x)
            return np.sin(2*np.pi*X) * np.cos(2*np.pi*Y) + np.random.randn(size, size) * 0.05
        else:
            raise ValueError("Dimension not supported")
    
    def _create_vector_field(self, dimension, size=20):
        """Create test vector field"""
        x = np.linspace(-1, 1, size)
        if dimension == 2:
            X, Y = np.meshgrid(x, x)
            Vx = np.sin(2*np.pi*X) + np.random.randn(size, size) * 0.05
            Vy = np.cos(2*np.pi*Y) + np.random.randn(size, size) * 0.05
            return np.stack([Vx, Vy], axis=-1)
        else:
            raise ValueError("Dimension not supported")
    
    def _create_tensor_field(self, dimension, size=10):
        """Create test tensor field"""
        if dimension == 2:
            field = np.random.randn(size, size, 2, 2) * 0.1
            # Make symmetric
            field[:, :, 0, 1] = field[:, :, 1, 0]
            return field
        else:
            raise ValueError("Dimension not supported")
    
    def _energy_functional(self, field_flat, field_type, dimension):
        """Compute energy functional for field"""
        if field_type == 'scalar':
            field = field_flat.reshape(int(np.sqrt(len(field_flat))), int(np.sqrt(len(field_flat))))
            # Simple energy: gradient squared + potential
            grad_x = np.gradient(field, axis=0)
            grad_y = np.gradient(field, axis=1)
            kinetic = np.sum(grad_x**2 + grad_y**2)
            potential = np.sum(field**4 - field**2)
            return kinetic + potential
        
        elif field_type == 'vector':
            size = int(np.sqrt(len(field_flat) // 2))
            field = field_flat.reshape(size, size, 2)
            Vx, Vy = field[:, :, 0], field[:, :, 1]
            # Energy includes divergence and curl terms
            div_V = np.gradient(Vx, axis=0) + np.gradient(Vy, axis=1)
            curl_V = np.gradient(Vy, axis=0) - np.gradient(Vx, axis=1)
            return np.sum(div_V**2 + curl_V**2 + Vx**2 + Vy**2)
        
        else:  # tensor
            size = int(np.sqrt(len(field_flat) // 4))
            field = field_flat.reshape(size, size, 2, 2)
            energy = 0
            for i in range(2):
                for j in range(2):
                    grad = np.gradient(field[:, :, i, j])
                    energy += np.sum(grad**2) + np.sum(field[:, :, i, j]**2)
            return energy
    
    def symmetry_analysis(self):
        """Test symmetry properties in field configurations"""
        print("=== Testing Symmetry Analysis ===")
        
        # Test translational symmetry
        field = self._create_scalar_field(2)
        original_energy = self._energy_functional(field.flatten(), 'scalar', 2)
        
        # Shift field
        shifted_field = np.roll(field, 5, axis=0)
        shifted_energy = self._energy_functional(shifted_field.flatten(), 'scalar', 2)
        
        # Test rotational symmetry
        rotated_field = np.rot90(field)
        rotated_energy = self._energy_functional(rotated_field.flatten(), 'scalar', 2)
        
        symmetry_results = {
            'translational_invariance': abs(original_energy - shifted_energy) < 1e-10,
            'rotational_invariance': abs(original_energy - rotated_energy) < 1e-10,
            'energy_differences': {
                'translational': abs(original_energy - shifted_energy),
                'rotational': abs(original_energy - rotated_energy)
            }
        }
        
        self.results['symmetry_analysis'] = symmetry_results
        return symmetry_results
    
    def computational_complexity_test(self):
        """Test computational scaling with field size"""
        print("=== Testing Computational Complexity ===")
        
        sizes = [10, 20, 30, 40]
        times = []
        
        for size in sizes:
            import time
            field = self._create_scalar_field(2, size)
            
            start_time = time.time()
            energy = self._energy_functional(field.flatten(), 'scalar', 2)
            end_time = time.time()
            
            times.append(end_time - start_time)
            print(f"Size {size}x{size}: {end_time - start_time:.4f} seconds")
        
        # Estimate scaling
        if len(times) >= 2:
            scaling = np.log(times[-1] / times[0]) / np.log((sizes[-1]/sizes[0])**2)
        else:
            scaling = 0
        
        complexity_results = {
            'sizes': sizes,
            'times': times,
            'estimated_scaling': scaling,
            'complexity_class': 'O(n^{})'.format(round(scaling, 1))
        }
        
        self.results['complexity_analysis'] = complexity_results
        return complexity_results
    
    def run_all_tests(self):
        """Run comprehensive test suite"""
        print("=== Running Comprehensive MFT Test Suite ===")
        
        # Run all tests
        self.analyze_10_4321_properties()
        self.field_minimization_test('scalar', 2)
        self.field_minimization_test('vector', 2)
        self.symmetry_analysis()
        self.computational_complexity_test()
        
        # Save results
        self.save_results()
        
        return self.results
    
    def save_results(self):
        """Save test results to file"""
        filename = f'mft_test_results_{self.timestamp.replace(":", "-")}.json'
        with open(filename, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)
        print(f"Results saved to {filename}")
        return filename

def main():
    """Main test execution"""
    analyzer = MFTAnalyzer()
    results = analyzer.run_all_tests()
    
    # Print summary
    print("\n=== Test Summary ===")
    if '10_4321_analysis' in results:
        mft_rel = results['10_4321_analysis']['mft_relevance']
        print(f"10^4321 MFT Relevance Score: {mft_rel['score']:.2f}")
        print("Insights:")
        for insight in mft_rel['insights']:
            print(f"  - {insight}")
    
    print("\nAll tests completed successfully!")

if __name__ == "__main__":
    main()