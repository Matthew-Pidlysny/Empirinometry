# Empirinometry
My evolving paper to the scientific community on logical operations in mathematics.  I give it this way 
because I feel this addresses all concerns.  I also do not make light of the obvious, only to say rules 
and foundations to a degree that is certain.  In that, you will find that everything has it's purpose, 
and where you NEED to assess the obvious I try to give it that way.  As it stands, it's in review with 
the American Mathematical Society, but since then I have updated it with necessities so I may have to 
resubmit.  Let's get this going, though, this should be a world project, all who want to participate are 
encouraged to Email me with the address in the main document.

In short, Bitsigning is all about checking itself.  I found a mathematical way to make what the computer 
did for me come to life, and that is math genius to assert that now because of something that simple, 
there is a new understanding of how to assert something as simple as |Varia|^n x C / M, where the obvious 
might be obvious to you.  I leave that to the test as you read the other document, see if you were right 
in figuring that out.  I leave the rest to humanity, bearing consideration with what I'm doing.  Anyone 
who wants to upload files here should message me through the same E-mail I mentioned.

Also, for those uploading this data to an AI, you will need to tell it a few things:

1.  Do not reformat the equation to your interests, solve normally.
2.  Everything is in Linear Mathematics terms as far as iteration goes, you will need to tell it that
    you are replacing x and y with common values in sets after each other, not to mention the Material
    Impositions found.
3.  These dynamics can adapt to literally any situations, not the ones that the examples in it seem to
    confine the AI to normally.

Cheers, and GISL!

# CONTACT INFO

Address:  7-252 Penetanguishene Rd, Barrie, ON, L4M-7C2
 
Email:  mattpidlysny@gmail.com
   
Whatsapp (Text Only):  +1(705)715-5128

Discord:  Poimandres#6015

X:  https://x.com/XThe9th

Facebook:  https://www.facebook.com/matthew.pidlysny/

==============================================================

'![ News Articles ]!'

== 2025-04-22 07:20 EST ==

The official word is in!  NONE of you are generating pull requests, not even with my little fan service going
on!  I guess that's how I have to take it, but you know.  Games are games, with almost 300 clones I am SHOCKED
that there are no pull requests, but IF there aren't any for real, I assume the best of you and know you are only
trying your best with the material.  Just find it hard to believe, is all.

Am I wrong?  Are you pull requesting?  Github doesn't think so, if that's true.  Now you have their official word
on it.

== 2025-04-20 18:37 EST ==

So I've mentioned that I've been "hearing" some of you.  Please don't worry:  I do not have any spying devices 
anywhere at any time.  I only hear what is going on around me and, for what it's worth, I assume it is just static
noise most of the time, but sometimes I hear things I understand more than others, and what I hear of what may be
any of you in the matter is completely anonymous but prevalent at times in me.  I don't steal your idea's, and I'll
tell you outright that 124 came from one of you, and I attribute that to group work.  Anytime it is like that in the
future, I will mention it.

As for the new formula's and hypotheses, keep in mind that we are nearing the bend on Empirinometry.  Just know, I
would be THRILLED if we threw it away because now we had a mechanic by other devices to contribute to it all, to have
a check that could just be used to define if something is within the accepted scope of variation, and pass it that
way.  I wish you luck in that determination, may we all succeed.

EDIT:  Also, congratulations everybody, we got 100 unique clones!  Good to see it translated into some authentic
       subscription to the archive, when I see total clones I know when it grows those are interested updates.  Thank
       you for sticking around! 

== 2025-04-18 19:56 EST == 

Hey, as you may have noticed, I've updated the main document with the formula's from the Formula-Bin folder.  It
will lead us to great remarks, and through the wind I hear some people saying M2 will be binomial somehow and 
possessive thereof.  I want to make clear to these people I dream of, if you are there, you need to be able to
iterate in that sequence, or there can be none of it.  One of the sciences will use it and cause it to fail, and
should numbers in one case not be universally applied?  It will make sense in time, just be patient and work hard,
you have mine on it.

As for your pull requests, I have not gotten them, nor do I expect to in the near future.  When I messaged them 
earlier, they notified me in a boilerplate way that all pull requests are "in the yellow".  If you're having any
luck on your end otherwise, I can be assured that means I'm being targeted and I don't really like it, but as long
as YOU can use this knowledge freely then that's all I care about, just use it under GPL, right?  Also, check the
street team folder for a funny few memes I thought would go great with any promotion on the street or online you 
end up doing.  I dunno, a picture to go with your post if any at all is all I can offer to bypass this seemingly
intentional blocking.  I will await my email back from Github to be sure of anything, I sent it on Wednsesday.

Also noticed nobody joined the Discord, was it something I said? :P

== 2025-04-17 04:48 EST ==

I'm updating the explanations for the Empirinometry.pdf file, I'm sorry I might have said that was the last of
the edits, but I had to make a correction on my explanation.  I'm sure a great amount of you were content with
knowing my formula and seeing ME get it wrong in explanation, but I go through things.  I didn't really know HOW
to explain what I came up with on my own, only that I knew it worked and I was hyper excited.  So, my explanations
are there, be well with your day and enjoy!

== 2025-04-16 22:42 EST ==

So who wants to talk?  I have a Discord server, which is general purpose but will do the job for this topic.  I
need you guys only to post in the Empirinometry section when it comes to this stuff, but there are other channels
on the server, we can talk about anything really, and you can get to know me better.  Here's the link:

https://discord.gg/paPNpYzT

See you there!  Let's bypass this blockage!

== 2025-04-15 16:05 EST ==

How can it be that I make the formula equating SOME of what God can do in his own right?  I have seen into
this a little, and come up with my own theory.  Get ready to blow your own mind when you get your measurement
devices.  Even if this remains only a theory, I stand to say it substantiates itself.  And also, we have reached
100 individual clones, though sitting around 58 unique clones.  Just waiting for GitHub to get off it's bum and
send me my pull requests, I KNOW you've been sending them to me.  I just don't see them at all, so I gotta figure
that one out when it comes.  Anyway, enjoy everything guys!

== 2025-04-15 13:45 EST ==

Just a bit of "lake humour" for all those concerned with what is going on here in this repository:

https://imgflip.com/i/9qwmz4

Cheers, really HOPE to talk to you all soon! ;)

== 2025-04-14 21:34 EST ==

Wanted to let everyone know, the document "empirinometry.pdf" is complete as for now, I will be putting
more things into the other two folders as time progresses and leaving this as my current remark, along
with the theory for obtaining Spectrum Ordinance for the use of M^1.  I want to leave with this closing
remark:  One thing unexplained from the document is the versatility of all this.  When you obtain the
Spectrum Ordinance properly, it really brings the world together.  2000 means different things on 
different scales, and what can be in charge of that but you all with me together?  I mean, think about
the level we could take our understanding, when computers make combined sums because they save the data
from the current solution and make it work as a confirmation for a whole slew of things?  I just want
this new empirical outlook to be defining of something even as simple as making smartphones faster, all
because they stored their sums properly.

I will be putting alot more out, but PLEASE try to make a commit and send me a pull request, anything 
fun that could be mind tickling on the matter should be fine.  You can even leave your name blank if it
makes you feel better.  All in all, be well everybody, and let's do this thing!

== 2025-04-14 20:50 EST ==

I would love to give you all another update.  I'm currently working with the value AbSumDicit, and
have come across at least one way, although incomplete, to word the formula at a base level.  For this
example I imagine a small cube, in flux but ultimately not in a position to rapidly change in a stable
system.  I have not factored in temperature here yet, but just to describe what I see out of the whole 
thing, take this into consideration:

|AbSumDicit| ^ 1 = |Varia| ^ N * C * F

Here I make use of AbSumDicit, specified in it's first Specified Intermission for the course of gaining
a Foundational Target.  In this theory, a cube of unknown mass is in flux, as all matter based things
seem to be on some level.  I ascribe here, being that N means number of variations, C means speed of
light, and F means Flux measured in couloumbs.  When it comes to this repose being a form of AbSumDicit,
we can infer that if mathematically true (Though the formula may need some work), it would prove that it
equated to being God Manifest in the world somehow, in as simple a thing as a cube of any mass not being
caused to be in a state of volatility.  

Change the cube, add a value, maybe it's Pink throughout and that is a variation, you make of it what you 
will.

Ultimately, I see |Soul| and it's composite interests being used in much the same way.  Let's define God,
shall we?  Even though we can only hope to be limited in our full understanding of him for this current
generation, maybe we will even embark on greater futures later with it?  And why not, when's the last time
anyone really put God into an equation seriously?  Sorry to be political but in my honest opinion, I see
the current understanding of Mathematics and Science as limiting of that notion by some unknown pattern
that is emerging, like it didn't matter because nobody else did it so far, and everyone thinks its 
"silly" in some way.  But, I have my theory, I stand by it.  Go ahead and say the value generated for
AbSumDicit is just a number, it clearly is not when in context with the quantum engineers that are humans.

== 2025-04-14 10:47 EST ==

Just a small note.  |Varia| is NOT Frequency, though it can distribute the same knowledge, it ceases
to be |Varia| and becomes something else, I'll let you all describe it for yourselves.  When you want
to understand Frequency in tandem with |Varia|, keep in mind what you're working with.  Remember,
failsums are illegal in Empirinometry, even though I give examples I make note that even some of my
formula's develop failsums as worded.  You will have to do your work to provide REAL data, and that
means understanding what YOU YOURSELF mean about Frequency when measured.

== 2025-04-13 17:12 EST == 

Make way for the good, is what I say!  Somehow, I feel in my heart people are cloning for the right
reason, and I believe in you all, go for gold!  All I wanted to say is that I updated the main document
so that it is easier for AI to understand things, and derive it's own function.  I will add one more
thing I think is clear for it to resolve but I see ChatGPT understanding it, if only to be explained on
certain things, but it itself came up with a working formula which it can use however it likes.

I hope everything is going great with your research, please be well!

== 2025-04-13 14:05 EST ==

Now, as all of you can see, we have some empirical observations to make with all this.  We have the
newly suggested path for understanding Spectrum Ordinance with the M1 theory, I to stand to say it
is the best shot we've got at specifying that Specified Intermission of the theory.  But now it comes
down to making units of measurement for the whole ordeal.  I beg, no, more or less formally consider
with the best of intentions for you, that we develop the theory in the Hypotheosis folder at once,
I want to see pull requests but obviously people may think this is my idea entirely.  I keep this all
under GPL, as will all of you in proceeding, but it is a WORLD idea, not just for me to sit on and be
king of.  I will petition to be out of the way of anyone seeking to make a stand in all of this.

Also, for what it's worth, let's consider one thing.  When it comes to other version of M's Specified
Intermission, I do hope everyone ELSE comes together.  To be formal, I will stop deriving them and hope
for the scientific community at large to deliver mechanisms of understanding M through the Varia Equation,
with due prejudice I hope.

On that note I leave you, but do understand, Spectrum Ordinance may or may not be our future, it will
take all of us to break it, since it seems so fully in place as is.  Good luck to you all, may Allah
SWT bless you and your families and all those you love.

== 2025-04-11 14:34 EST ==

So I have a lesson for Empirinometry.  There is a "sum" called AbSumDicit I have mentioned in the laws
of it, and I only want you to know I leave it there for the recollection of those who want to quantify
where otherwise it is impossible.  It is, perhaps, that Empirinometry can provide Approximations of a
sort, and in this we can see the power of it, IF the fundamental of the Mechanical Substantiation and
Formulation (Math, in other words) is correct on a basic and tested level.  I want to say now WHY I 
made the Material Imposition into law, as some find that limiting of consciousness.

Take, for example, my little Greek flag pin.  It's not worth anything, literally a piece of paper with
the Greek flag on it on a toothpick, given from a Church event eventually to me.  I have used it in
different places, and this is quite substantiated so far by math in itself if you take sensible inputs
and operations into consideration, but to be fair, there is an anomaly of the now to consider.  I have
placed it temporarily in a place of my choosing on my desk, more or less unconsciously as we all know
ourselves.  Now, what I mean by AbSumDicit is the probability answered that I will never move the 
pin for a long time.  I have been meaning to deal with the pin internally for some time, literally I
would look at the pin and say I would move that pin, and for the life of me I have yet still, despite
every conscious reminding, to move it because simply put, I am a stubborn lazy person sometimes, and 
that is quantifiable in many regards.  

It only leaves to stand that I correct my work in what it left unsaid and say Operation > will be there 
placed before AbSumDicit when understood as the transitive sense of the thing, and simply "not when not",
and I hope that answers alot of questions.  Now, as you read in the document (If not, definitely check
it out if you have interest with this readme), Empirinometry can only hope to be the describer in SOME
senses, but the penultimate formulator even in express mechanics, being that the formula's in the
document do not detail AbSumDicit.  I leave that to you, and leave you with this adage:

There is Empirisim in it,
There is Empironomy of it,
There is Empirinomics concerning it,
And there is Empire to gain after it.
I stand here respectful,
May Empirinometry be the core of Varia,
Now and again...
